
	<div class="changelog">
		<ul class="release-list">
			<li>
				<h3><?php echo __('Release', 'framework'); ?></h3>
				<p>
					<strong><?php echo __('Version 1.2', 'framework'); ?></strong>
				</p>
			</li>
			<li>
				<h3><?php echo __('Release', 'framework'); ?></h3>
				<p>
					<strong><?php echo __('Version 1.1.1', 'framework'); ?></strong>
				</p>
			</li>
			<li>
				<h3><?php echo __('Release', 'framework'); ?></h3>
				<p>
					<strong><?php echo __('Version 1.1', 'framework'); ?></strong>
				</p>
			</li>
			<li>
				<h3><?php echo __('Release', 'framework'); ?></h3>
				<p>
					<strong><?php echo __('Version 1.0.1', 'framework'); ?></strong>
				</p>
			</li>
			<li>
				<h3><?php echo __('Initial Release', 'framework'); ?></h3>
				<p>
					<strong><?php echo __('Version 1.0', 'framework'); ?></strong>
					- <?php echo __('Initial release version.', 'framework'); ?>.
				</p>
			</li>
			<li>
				<h3><?php echo __('Beta 1', 'framework'); ?></h3>
				<p>
					<strong><?php echo __('Version 0.1', 'framework'); ?></strong>
					- <?php echo __('Core functionality created', 'framework'); ?>.
				</p>
			</li>
		</ul>
	</div>
