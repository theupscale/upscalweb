<?php

class Directory_Settings_Object {	

	function __construct() {
		//
	}	
}

?>
